/**
 * Plugin admin end script
 *
 * @package Pootle_Page_Builder_Live_Editor
 * @version 1.0.0
 * @developer shramee <shramee.srivastav@gmail.com>
 */
jQuery( function ( $ ) {
	//$('#wp-content-editor-tools').prepend( '<a class="button live-editor pootle" href="' + live_editor_url + '">Live Editor</a>' );
} );