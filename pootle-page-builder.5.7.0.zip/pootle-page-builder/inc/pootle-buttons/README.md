# pootle-buttons
A simple button add on for Pootle page builder
