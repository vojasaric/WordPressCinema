<?php

require_once POOTLEPB_DIR . 'inc/modules/pootle-cloud.php';
require_once POOTLEPB_DIR . 'inc/modules/metaslider.php';
require_once POOTLEPB_DIR . 'inc/modules/ninja-forms.php';
require_once POOTLEPB_DIR . 'inc/modules/pootle-slider.php';
require_once POOTLEPB_DIR . 'inc/modules/free-modules.php';
