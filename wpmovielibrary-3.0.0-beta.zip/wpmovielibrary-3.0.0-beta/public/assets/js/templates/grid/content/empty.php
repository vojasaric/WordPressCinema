<?php
/**
 * Empty Grid JavaScript template.
 *
 * @since 3.0.0
 */

?>

				<div class="wpmoly empty notice">
					<div class="notice-content">
						<p><?php _e( 'No items found.', 'wpmovielibrary' ); ?></p>
					</div>
				</div>
