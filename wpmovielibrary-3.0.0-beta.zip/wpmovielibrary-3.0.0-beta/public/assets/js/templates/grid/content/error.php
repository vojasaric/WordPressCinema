<?php
/**
 * Grid Error JavaScript template.
 *
 * @since 3.0.0
 */

?>

				<div class="wpmoly error notice">
					<div class="notice-content">
						<p>{{ data.message }}</p>
					</div>
					<div class="notice-footnote">{{ data.footnote }}</div>
				</div>
