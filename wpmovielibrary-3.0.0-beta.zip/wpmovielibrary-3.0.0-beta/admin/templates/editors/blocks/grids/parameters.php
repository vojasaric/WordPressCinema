<?php
/**
 * Grid Editor Parameters Block Template
 *
 * @since 3.0.0
 *
 * @uses $id
 * @uses $title
 */
?>

					<div id="editor-<?php echo esc_attr( $id ); ?>-block" data-controller="ParametersBlock" class="editor-block post-editor-block grid-editor-block grid-parameters-block"></div>
