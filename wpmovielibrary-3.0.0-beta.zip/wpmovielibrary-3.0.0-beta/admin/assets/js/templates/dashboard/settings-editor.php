<?php
/**
 * Dashboard Setting Editor Template
 *
 * @since 3.0.0
 */
?>

					<div id="settings-menu" class="settings-menu"></div>
					<div id="settings-content" class="settings-content"></div>
