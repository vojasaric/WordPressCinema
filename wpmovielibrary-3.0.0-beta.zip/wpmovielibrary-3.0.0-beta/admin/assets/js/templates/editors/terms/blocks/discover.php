<?php
/**
 * Term Browser 'Discover' Block Template.
 *
 * @since 3.0.0
 */
?>

							<p>{{{ data.total_terms }}}</p>
							<ul class="links-list">
								<li class="list-item"><span class="wpmolicon icon-right-open"></span> <a href="{{ wpmolyEditorL10n.old_edit_link }}">{{ wpmolyEditorL10n.old_edit_label }}</a></li>
							</ul>
