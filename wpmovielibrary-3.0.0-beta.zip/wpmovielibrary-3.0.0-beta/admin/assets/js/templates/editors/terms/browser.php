<?php
/**
 * Term Browser Template.
 *
 * @since 3.0.0
 */
?>

		<div class="loader"></div>
