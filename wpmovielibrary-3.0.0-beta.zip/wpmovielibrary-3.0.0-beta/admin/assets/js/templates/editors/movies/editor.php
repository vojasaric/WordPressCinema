<?php
/**
 * Movies Editor Main Template
 *
 * @since 3.0.0
 */
?>

		<div id="wpmoly-movie-menu" class="editor-section editor-menu"></div>

		<div id="wpmoly-movie-preview" class="editor-section preview-section"></div>

		<div id="wpmoly-movie-search" class="editor-section search-section"></div>

		<div id="wpmoly-movie-snapshot" class="editor-section snapshot-section"></div>
