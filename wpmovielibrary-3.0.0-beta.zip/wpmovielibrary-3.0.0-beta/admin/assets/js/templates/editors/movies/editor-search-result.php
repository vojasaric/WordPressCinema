<?php
/**
 * Movies Editor Search Result Template
 *
 * @since 3.0.0
 */
?>

				<div class="result-thumbnail" style="background-image:url(https://d3v.wpmovielibrary.com/wp-content/plugins/wpmovielibrary/public/assets/img/poster-small.jpg)">
					<div class="result-menu">
						<button type="button" class="button queue"><span class="wpmolicon icon-edit"></span></button>
						<button type="button" class="button import"><span class="wpmolicon icon-download"></span></button>
					</div>
				</div>
				<div class="result-year">2018</div>
				<div class="result-title"><a href="#" title="">Lorem ipsum dolor sit amet</a></div>
