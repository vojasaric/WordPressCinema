<?php
/**
 * Movies Editor Preview Template
 *
 * @since 3.0.0
 */
?>

		<div id="wpmoly-movie-meta" class="editor-section meta-section"></div>
		<div id="wpmoly-movie-credits" class="editor-section credits-section"></div>
		<div id="wpmoly-movie-posters" class="editor-section posters-section"></div>
		<div id="wpmoly-movie-backdrops" class="editor-section backdrops-section"></div>
