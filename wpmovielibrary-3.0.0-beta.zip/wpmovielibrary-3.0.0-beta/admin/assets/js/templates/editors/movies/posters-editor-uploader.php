
					 <div class="uploader-dropzone"></div>
					 <div class="uploader-container">
             <div class="poster uploader-browser">
               <div class="poster-thumbnail">
                 <button type="button" class="button" data-action="select-image"><span class="wpmolicon icon-upload"></span></button>
               </div>
             </div>
           </div>
