<?php
/**
 * Movie Modal Template.
 *
 * @since 3.0.0
 */
?>

		<div class="movie-modal-backdrop"></div>

		<div class="movie-modal-content"></div>

		<div class="movie-modal-loading"></div>
