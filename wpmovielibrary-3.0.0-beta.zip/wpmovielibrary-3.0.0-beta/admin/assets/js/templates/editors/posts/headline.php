<?php
/**
 * Post Editor Headline Template
 *
 * @since 3.0.0
 */
?>

		<a href="{{ wpmolyEditorL10n.edit_link }}" class="button" title="{{ wpmolyEditorL10n.back_to_edit }}"><span class="wpmolicon icon-left-arrow"></span></a><span class="post-title">{{ data.title.rendered || '' }}</span>
