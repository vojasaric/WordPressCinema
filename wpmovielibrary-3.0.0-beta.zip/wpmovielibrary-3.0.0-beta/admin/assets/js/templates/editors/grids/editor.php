<?php
/**
 * Grid Editor Template
 *
 * @since 3.0.0
 */
?>

		<div id="wpmoly-grid-headline" class="wp-heading-inline"></div>

		<div id="wpmoly-grid-preview" class="editor-section preview-section">
			<div class="wpmoly grid" data-preview-grid="{{ data.post_id }}"></div>
		</div>

		<div id="wpmoly-grid-meta" class="editor-section meta-section"></div>
