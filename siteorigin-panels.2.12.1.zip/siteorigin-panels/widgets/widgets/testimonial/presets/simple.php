<?php

return array(
	'clean' => array(
	),
);
