<?php get_header(); ?>

<div id='container'>
	<?php get_template_part('loop'); ?>
</div>

<?php get_sidebar(); ?>
	
<?php get_footer(); ?>