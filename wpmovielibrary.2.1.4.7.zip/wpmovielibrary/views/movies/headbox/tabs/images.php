<?php
/**
 * Movie Headbox Images Tab Template view
 * 
 * Showing a movie's headbox images tab.
 * 
 * @since    2.0
 * 
 * @uses    $images
 */
?>

				<div class="wpmoly headbox movie meta images">
<?php echo $images ?>
				</div>
