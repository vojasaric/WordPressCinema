<?php
/**
 * Movie Headbox Meta Tab Template view
 * 
 * Showing a movie's headbox meta tab.
 * 
 * @since    2.0
 * 
 * @uses    $actors
 */
?>

				<?php echo __( 'Starring:', 'wpmovielibrary' ) . ' ' . $actors ?>