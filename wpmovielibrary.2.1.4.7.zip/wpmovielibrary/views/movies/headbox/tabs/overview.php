<?php
/**
 * Movie Headbox Overview Tab Template view
 * 
 * Showing a movie's headbox overview tab.
 * 
 * @since    2.0
 * 
 * @uses    $overview
 */
?>

				<p><span class="hide-if-no-js wpmolicon icon-overview"></span> <?php echo $overview ?></p>