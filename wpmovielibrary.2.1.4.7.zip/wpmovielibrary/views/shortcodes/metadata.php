<?php
/**
 * Metadata Shortcode view Template
 * 
 * Showing a specific movie metadata.
 * 
 * @since    1.2
 * 
 * @uses    $movies
 */
?>

	<span class="wpmoly shortcode item meta <?php echo $key ?> value"><?php echo $meta ?></span>
