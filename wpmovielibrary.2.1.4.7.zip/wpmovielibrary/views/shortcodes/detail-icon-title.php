<?php
/**
 * Iconed Detail Shortcode view Template
 * 
 * Showing a specific movie detail with icon.
 * 
 * @since    1.2
 * 
 * @uses    $detail
 * @uses    $data
 */
?>

	<div class="wpmoly shortcode item detail icon <?php echo $detail ?>"><span class="wpmolicon icon-<?php echo $data ?>"></span>&nbsp; <?php echo $title ?></div>
