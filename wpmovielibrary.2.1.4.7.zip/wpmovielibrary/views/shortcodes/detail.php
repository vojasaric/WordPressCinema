<?php
/**
 * Detail Shortcode view Template
 * 
 * Showing a specific movie detail.
 * 
 * @since    1.2
 * 
 * @uses    $detail
 * @uses    $data
 * @uses    $title
 */
?>

	<div class="wpmoly shortcode block <?php echo $detail ?> <?php echo $data ?> label"><span class="wpmoly shortcode item detail title"><?php echo $title ?></span></div>
