<?php
/**
 * Genres Shortcode view Template
 * 
 * Showing a specific movie genres.
 * 
 * @since    1.2
 * 
 * @uses    $genres
 */
?>

	<span class="wpmoly shortcode item genre value"><?php echo $genres ?></span>
