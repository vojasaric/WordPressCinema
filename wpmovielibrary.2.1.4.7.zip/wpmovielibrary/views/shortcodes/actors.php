<?php
/**
 * Actors Shortcode view Template
 * 
 * Showing a specific movie actors.
 * 
 * @since    1.2
 * 
 * @uses    $movies
 */
?>

	<span class="wpmoly shortcode item actor value"><?php echo $actors ?></span>
