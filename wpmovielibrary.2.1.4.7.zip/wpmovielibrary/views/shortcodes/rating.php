<?php
/**
 * Detail (rating) Shortcode view Template
 * 
 * Showing a specific movie rating.
 * 
 * @since    1.2
 * 
 * @uses    $style
 */
?>

	<div class="wpmoly detail rating"><?php echo $data ?></div>
