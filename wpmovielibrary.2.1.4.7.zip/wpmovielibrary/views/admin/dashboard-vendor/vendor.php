
							<div class="main">
								<p class="title">
									<?php _e( 'Use it, love it, rate it!', 'wpmovielibrary' ) ?>
								</p>
								<p class="rateme">
									<a href="http://wordpress.org/support/view/plugin-reviews/wpmovielibrary?rate=5#postform" title="<?php _e( 'Give us five shiny stars!', 'wpmovielibrary' ) ?>">
										<span class="wpmolicon icon-star-filled"></span><span class="wpmolicon icon-star-filled"></span><span class="wpmolicon icon-star-filled"></span><span class="wpmolicon icon-star-filled"></span><span class="wpmolicon icon-star-filled"></span>
									</a>
								</p>
								<p class="joinus"><?php _e( 'We\'re social guys, join us:', 'wpmovielibrary' ) ?><br /><small><?php _e( 'We have cookies!', 'wpmovielibrary' ) ?></small></p>
								<ul class="social">
									<?php echo $links ?>
								</ul>
							</div>
