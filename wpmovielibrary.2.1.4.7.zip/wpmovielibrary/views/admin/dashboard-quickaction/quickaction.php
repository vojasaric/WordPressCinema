
							<div class="main">
								<ul>
									<?php echo $links ?>
								</ul>
							</div>
