
	<div id="wpmoly-movie-modal-bg">
		<div id="wpmoly-movie-modal">
			<div id="wpmoly-movie-modal-inner"></div>
			<a href="#" id="wpmoly-movie-modal-close"><span class="wpmolicon icon-no-alt"></span></a>
			<div id="wpmoly-movie-modal-poster">
				<img src="" alt="" />
			</div>
			<div id="wpmoly-movie-modal-content">
				<h2 id="wpmoly-movie-modal-title"></h2>
				<div id="wpmoly-movie-modal-meta">
					<span id="wpmoly-movie-modal-release_date"></span>
					<span>&ndash;</span>
					<span id="wpmoly-movie-modal-runtime"></span>
					<span>&ndash;</span>
					<span id="wpmoly-movie-modal-rating"><div id="wpmoly-movie-rating-" class="wpmoly-movie-rating wpmoly-movie-modal-rating wpmoly-movie-rating-0-0"><span class="wpmolicon icon-star-empty"></span><span class="wpmolicon icon-star-empty"></span><span class="wpmolicon icon-star-empty"></span><span class="wpmolicon icon-star-empty"></span><span class="wpmolicon icon-star-empty"></span></div></span>
				</div>
				<div id="wpmoly-movie-modal-overview"></div>
				<div id="wpmoly-movie-modal-links">
					<a class="button button-primary" id="wpmoly-movie-modal-edit" href=""><span class="wpmolicon icon-edit-page"></span>&nbsp; <?php _e( 'Edit' ) ?></a>
					<a class="button button-primary" id="wpmoly-movie-modal-view" href=""><span class="wpmolicon icon-preview"></span>&nbsp; <?php _e( 'View' ) ?></a>
				</div>
			</div>
		</div>
	</div>