	<span id="<?php echo str_replace( 'wpmoly_settings-', 'wpmoly_section_', $section['id'] ) ?>"></span>
