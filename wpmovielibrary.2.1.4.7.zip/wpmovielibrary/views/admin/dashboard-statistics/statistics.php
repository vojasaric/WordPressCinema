
							<div class="main">
								<p><?php _e( 'Here\'s some statistics about your movie library:', 'wpmovielibrary' ) ?></p>
								<ul>
									<?php echo $links ?>
								</ul>
								<p>
									<?php echo $text ?>
								</p>
							</div>
