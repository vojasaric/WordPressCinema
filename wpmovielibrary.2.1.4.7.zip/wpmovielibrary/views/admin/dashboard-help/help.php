
							<div class="main">
								<p><?php _e( 'Here are some useful links:', 'wpmovielibrary' ) ?></p>
								<ul>
									<?php echo $links ?>
								</ul>
							</div>
